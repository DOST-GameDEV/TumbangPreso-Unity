# Unity Bug Investigation Skill

A Codex skill for evidence-based Unity debugging.

## Structure

- `SKILL.md`: investigation workflow and router
- `foundations/`: evidence, hypotheses, reproduction, instrumentation, safety
- `specializations/`: defect-area guidance
- `frameworks/`: framework-specific debugging
- `references/`: templates and capability model

## Recommended pairing

- `unity-project-onboarding`
- `unity-feature-implementation`
- `unity-build-validation`

## Design philosophy

- evidence before edits
- reproduce before fixing
- symptoms are not causes
- one hypothesis experiment at a time
- smallest justified fix
- precise validation
- explicit uncertainty
