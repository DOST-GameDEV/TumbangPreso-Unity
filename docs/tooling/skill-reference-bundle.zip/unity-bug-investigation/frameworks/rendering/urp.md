# URP Debugging

## Inspect

- URP version
- pipeline asset
- renderer asset
- renderer features
- camera stack
- shader targets
- volume configuration

## Common defects

- renderer feature missing or ordered incorrectly
- wrong renderer assigned
- incompatible shader target
- camera stacking assumption
- shared pipeline asset changed

## Validation

Check representative cameras, renderer assets, Console warnings, and target
platform.
