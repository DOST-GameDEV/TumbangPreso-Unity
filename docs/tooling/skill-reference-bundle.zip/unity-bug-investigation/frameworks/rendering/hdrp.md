# HDRP Debugging

## Inspect

- HDRP version
- pipeline assets
- custom passes
- volume profiles
- frame settings
- graphics API

## Common defects

- custom pass injection mismatch
- volume override disabled
- unsupported feature or hardware
- wrong frame setting
- shared HDRP asset mismatch

## Validation

Check representative volume, camera, custom pass, graphics API, and target
hardware.
