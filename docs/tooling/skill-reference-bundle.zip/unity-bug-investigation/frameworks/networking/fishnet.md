# FishNet Debugging

## Inspect

- ownership
- SyncTypes
- ServerRpc
- ObserversRpc
- TargetRpc
- prediction and reconcile
- spawn and despawn

## Common defects

- owner and observer logic mixed
- duplicate RPC effects
- reconcile state incomplete
- authority stale after despawn

## Validation

Test server, owner, and observers.
