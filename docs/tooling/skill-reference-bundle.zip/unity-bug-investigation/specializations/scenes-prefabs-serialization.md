# Scenes, Prefabs, and Serialization Bugs

## Inspect first

- base prefab and variants
- scene instances
- overrides
- missing references
- GUIDs and file IDs
- `FormerlySerializedAs`
- custom inspectors
- domain reload settings

## Common causes

- prefab variant override
- field rename
- missing meta file
- duplicated GUID
- wrong asset edited
- scene-specific reference in reusable prefab
- serialized type change

## Validation

- prefab and variants
- scene instances
- import
- missing-reference scan
- clean checkout or reimport when necessary
