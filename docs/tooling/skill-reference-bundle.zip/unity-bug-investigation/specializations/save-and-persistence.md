# Save and Persistence Bugs

## Inspect first

- representative failing save
- format version
- migration path
- defaults
- storage path
- cloud synchronization
- failure recovery
- platform differences

## Common causes

- changed field name or type
- missing migration
- invalid default
- partial write
- stale cache
- cloud conflict
- path permission
- culture-dependent serialization

## Validation

- new save
- failing old save
- missing fields
- partial or corrupted data
- save and reload
- platform path
