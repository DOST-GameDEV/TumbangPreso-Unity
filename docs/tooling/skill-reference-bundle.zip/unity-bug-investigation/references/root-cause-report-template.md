# Root Cause Report

## Summary

{{SUMMARY}}

## Symptom

{{SYMPTOM}}

## Expected behavior

{{EXPECTED}}

## Reproduction

{{REPRODUCTION}}

## Root cause

**Confidence:** Confirmed / Likely / Unresolved

{{ROOT_CAUSE}}

## Evidence

- {{EVIDENCE_1}}
- {{EVIDENCE_2}}

## Fix

{{FIX}}

## Regression coverage

{{REGRESSION}}

## Validation

{{VALIDATION}}

## Remaining risks

{{RISKS}}
