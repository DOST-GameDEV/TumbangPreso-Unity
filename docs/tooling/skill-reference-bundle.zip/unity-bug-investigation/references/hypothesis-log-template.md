# Bug Hypothesis Log

## Defect

**Observed:**

{{OBSERVED}}

**Expected:**

{{EXPECTED}}

**Reproduction:**

{{REPRODUCTION}}

## Baseline

- Unity: {{UNITY_VERSION}}
- Platform: {{PLATFORM}}
- Scene: {{SCENE}}
- Commit: {{COMMIT}}
- Frequency: {{FREQUENCY}}

## Hypotheses

| Rank | Hypothesis | Supporting evidence | Contradicting evidence | Predicted observation | Experiment | Status |
|---:|---|---|---|---|---|---|
| 1 | {{H1}} | {{H1_SUPPORT}} | {{H1_CONTRA}} | {{H1_PREDICTION}} | {{H1_TEST}} | untested |
| 2 | {{H2}} | {{H2_SUPPORT}} | {{H2_CONTRA}} | {{H2_PREDICTION}} | {{H2_TEST}} | untested |

## Findings

{{FINDINGS}}

## Root cause

**Status:** confirmed / likely / unresolved

{{ROOT_CAUSE}}

## Fix validation

{{FIX_VALIDATION}}
