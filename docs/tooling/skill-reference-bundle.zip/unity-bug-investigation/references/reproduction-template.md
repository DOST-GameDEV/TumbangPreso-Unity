# Bug Reproduction

## Environment

- Unity:
- Platform:
- Scene:
- Build type:
- Networking topology:
- Device:
- Commit:

## Preconditions

- 

## Steps

1. 
2. 
3. 

## Expected

## Observed

## Frequency

## Evidence

- Console:
- Stack trace:
- Screenshot or capture:
- Save or data:
- Profiler or network trace:

## Notes
