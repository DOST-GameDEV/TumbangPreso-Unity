# Windows Validation

## Check

- x86_64 architecture
- Mono or IL2CPP as intended
- Direct3D API
- executable and data folder
- redistributable or native plugin requirements
- file permissions
- save paths
- fullscreen and resolution
- launch on target Windows version
