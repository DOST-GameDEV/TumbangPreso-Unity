# WebGL Validation

## Check

- browser support
- memory size
- compression
- hosting headers
- threading restrictions
- filesystem persistence
- network and CORS
- audio autoplay restrictions
- input focus
- build size
- loading time
- unsupported APIs
