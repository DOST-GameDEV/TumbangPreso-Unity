# Dedicated Server Validation

## Check

- server build target or subtarget
- headless startup
- no graphics-dependent initialization
- command-line arguments
- port binding
- transport
- logging
- graceful shutdown
- scene loading
- no client-only package dependency
- container or host environment
- multiplayer clients can connect
