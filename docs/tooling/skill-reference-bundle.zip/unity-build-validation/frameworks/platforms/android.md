# Android Validation

## Check

- package identifier
- version code and version name
- minimum and target SDK
- ARM architectures
- IL2CPP
- permissions
- Gradle build
- signing availability
- AAB or APK output
- device installation
- storage paths
- lifecycle pause and resume
- graphics API
- memory on target device
