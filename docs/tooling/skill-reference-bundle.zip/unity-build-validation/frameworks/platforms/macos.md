# macOS Validation

## Check

- Intel, Apple Silicon, or universal architecture
- Metal
- app bundle
- signing and notarization requirements
- permissions
- native plugins
- save paths
- target macOS version
- launch on representative hardware
