# iOS Validation

## Check

- bundle identifier
- version
- IL2CPP
- Xcode export
- signing and provisioning availability
- required capabilities
- privacy usage descriptions
- architecture
- device launch
- pause and resume
- save paths
- graphics API
