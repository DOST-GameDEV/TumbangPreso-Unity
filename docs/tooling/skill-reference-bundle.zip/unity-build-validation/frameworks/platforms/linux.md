# Linux Validation

## Check

- x86_64 architecture
- executable permissions
- graphics API
- case-sensitive paths
- native libraries
- save paths
- headless behavior when relevant
- target distribution compatibility
