# Netcode for GameObjects Validation

## Validate

- NetworkManager startup
- transport and Relay when used
- host and remote client
- ownership validation
- ServerRpc and ClientRpc paths
- NetworkVariable state
- prefab registration
- scene transitions
- late join
- disconnect cleanup
- dedicated server when required
