# Mirror Validation

## Validate

- host path
- remote client path
- Commands
- ClientRpc and TargetRpc
- SyncVars and hooks
- authority
- spawnable prefabs
- scene transitions
- disconnect
- dedicated server when required
