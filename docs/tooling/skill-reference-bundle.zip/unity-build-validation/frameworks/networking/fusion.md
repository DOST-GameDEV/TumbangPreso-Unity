# Photon Fusion Validation

## Validate

- selected topology
- runner startup and shutdown
- input authority
- state authority
- networked properties
- RPC behavior
- prediction and resimulation
- owner and observer
- spawn and despawn
- late join
- disconnect
- multiple peers

## Strong evidence

Use at least two peers and exercise resimulation-sensitive behavior when
relevant.
