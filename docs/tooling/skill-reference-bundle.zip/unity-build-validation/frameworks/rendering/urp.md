# URP Validation

## Validate

- active URP asset
- renderer asset
- renderer feature ordering
- camera stacking
- shader graph targets
- shader compilation
- representative materials
- SRP Batcher compatibility when relevant
- target graphics API
- target platform
