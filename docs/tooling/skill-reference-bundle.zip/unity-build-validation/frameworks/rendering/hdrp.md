# HDRP Validation

## Validate

- active HDRP asset
- frame settings
- volume profiles
- custom passes
- shader compilation
- representative scenes
- graphics API
- target hardware
- ray tracing or advanced features when used
