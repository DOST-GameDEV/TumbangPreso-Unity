# Unity Build Validation Skill

A Codex skill for final Unity verification across compilation, Console, tests,
scenes, prefabs, runtime behavior, builds, platforms, networking, and release
criteria.

## Structure

- `SKILL.md`: validation workflow and router
- `foundations/`: evidence levels, baselines, safety, statuses
- `checklists/`: validation domains
- `frameworks/`: networking, rendering, and platform rules
- `references/`: plans, matrices, reports, and capabilities

## Recommended pairing

- `unity-project-onboarding`
- `unity-feature-implementation`
- `unity-bug-investigation`
- `unity-project-health-check`

## Design philosophy

- compilation is necessary but insufficient
- baseline before execution
- exact evidence
- acceptance-criteria traceability
- target-platform validation
- honest Ready, Blocked, Failed, and Not validated states
