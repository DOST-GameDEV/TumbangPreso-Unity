# Unity Validation Plan

## Scope

{{SCOPE}}

## Target

- Unity:
- Commit:
- Platform:
- Build configuration:
- Scenes:
- Networking topology:
- Device:

## Acceptance criteria

| ID | Criterion | Required evidence |
|---|---|---|
| AC-01 | {{CRITERION}} | {{EVIDENCE}} |

## Validation sequence

1. Baseline
2. Compilation and Console
3. Targeted tests
4. Broader tests
5. Scene and prefab inspection
6. Runtime smoke test
7. Target build
8. Platform or device checks
9. Artifact review

## Limitations

-
