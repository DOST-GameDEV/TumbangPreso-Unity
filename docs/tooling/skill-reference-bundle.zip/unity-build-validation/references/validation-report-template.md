# Unity Validation Report

> Date: {{DATE}}
> Commit: `{{COMMIT}}`
> Status: {{STATUS}}
> Platform: {{PLATFORM}}
> Configuration: {{CONFIGURATION}}

## Scope

{{SCOPE}}

## Baseline

{{BASELINE}}

## Acceptance criteria

{{ACCEPTANCE_MATRIX}}

## Compilation and Console

{{COMPILATION}}

## Tests

{{TESTS}}

## Scenes and serialized assets

{{SERIALIZED}}

## Runtime validation

{{RUNTIME}}

## Builds and artifacts

{{BUILDS}}

## Regressions

{{REGRESSIONS}}

## Limitations

{{LIMITATIONS}}

## Recommended next action

{{NEXT_ACTION}}
