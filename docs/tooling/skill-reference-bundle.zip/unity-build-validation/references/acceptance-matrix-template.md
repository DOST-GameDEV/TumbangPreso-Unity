# Acceptance Matrix

| ID | Criterion | Evidence | Status | Notes |
|---|---|---|---|---|
| AC-01 | {{CRITERION}} | {{EVIDENCE}} | Passed / Failed / Blocked / Not run / N/A | {{NOTES}} |
