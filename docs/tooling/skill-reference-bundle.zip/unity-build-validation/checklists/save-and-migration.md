# Save and Migration Checklist

## Check

- new save creation
- save and reload
- old save migration
- missing fields
- default values
- corrupted or partial data
- cloud synchronization
- platform paths
- atomic write behavior
- version metadata

Preserve representative failing or old saves.

Do not reset user data as the default validation method.
