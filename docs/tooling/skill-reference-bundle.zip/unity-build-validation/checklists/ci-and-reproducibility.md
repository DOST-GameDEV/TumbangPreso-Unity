# CI and Reproducibility Checklist

## Check

- documented command
- clean environment behavior
- pinned Unity version
- package resolution
- test result artifacts
- build artifact output
- non-zero failure exit codes
- secret injection
- cache behavior
- platform image or runner
- repeatability
- logs and failure visibility

A local success does not prove CI reproducibility.
