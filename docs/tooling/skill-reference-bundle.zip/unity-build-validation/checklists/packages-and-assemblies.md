# Packages and Assemblies Checklist

## Check

- manifest resolves
- lock file is consistent
- embedded and Git packages are available
- no missing local package path
- runtime and editor assemblies compile
- platform restrictions are valid
- test assemblies compile
- no runtime UnityEditor references
- optional dependencies are resolved
- package version supports target Unity version

Do not update packages during validation.
