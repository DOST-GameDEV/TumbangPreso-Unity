# Scenes and Build Settings Checklist

## Check

- required scenes exist
- enabled scenes are correct
- startup scene is valid
- scene order is intentional
- test or development scenes are excluded from release when required
- scene-loading paths are valid
- addressable scenes are accounted for
- no duplicate or stale scene entries
- build profile uses intended scenes

## Validation

Use Editor or serialized settings inspection.

Do not save scenes during read-only validation.
