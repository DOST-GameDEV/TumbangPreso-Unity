# Compilation and Console Checklist

## Check

- Unity import completed
- script compilation completed
- assembly errors
- package errors
- shader compilation messages
- Console errors
- Console warnings
- stack traces
- repeated error spam
- platform-specific compilation
- conditional compilation symbols

## Baseline

Record existing messages before validation.

## Pass criteria

- no new compilation errors
- no new required-feature runtime errors
- warnings classified
- pre-existing failures reported

Do not clear the Console before capturing evidence.
