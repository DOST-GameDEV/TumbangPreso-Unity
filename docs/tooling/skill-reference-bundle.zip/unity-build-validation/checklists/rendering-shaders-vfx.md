# Rendering, Shaders, and VFX Checklist

## Check

- active pipeline
- shader compilation
- Console warnings
- representative materials
- renderer features
- camera configuration
- visual result
- target graphics API
- VFX trigger
- repeated effect use
- pooled reset
- cleanup
- performance when required

Visual correctness requires actual visual inspection.
