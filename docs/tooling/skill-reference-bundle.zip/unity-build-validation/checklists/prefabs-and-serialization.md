# Prefabs and Serialization Checklist

## Check

- required references
- prefab variants
- nested prefabs
- scene instances
- ScriptableObject defaults
- serialized field renames
- `FormerlySerializedAs`
- changed field types
- `.meta` files
- GUID and file ID stability
- custom inspectors
- missing scripts

## Pass criteria

- no required missing references
- variants remain valid
- new assets include metadata
- changes are narrowly scoped
- Unity imports without new errors
