# Builds and Artifacts Checklist

## Before build

- target platform
- architecture
- scripting backend
- development or release
- scenes
- version
- output path
- required credentials
- required services

## During build

Record:

- command or method
- exit result
- warnings
- errors
- duration when useful

## After build

Verify:

- artifact exists
- expected files exist
- version metadata
- executable or package launches when appropriate
- logs are available
- output is outside source directories
- artifact path is reported
