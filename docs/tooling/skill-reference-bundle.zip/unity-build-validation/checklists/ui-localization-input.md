# UI, Localization, and Input Checklist

## UI

- primary interaction
- repeated open and close
- navigation and focus
- resolution and scaling
- safe areas
- hidden view cleanup

## Localization

- user-facing strings
- locale switching
- fallback behavior
- dynamic values
- font support

## Input

- primary device
- controller when supported
- action-map transitions
- enable and disable
- rebinding
- local multiplayer ownership
