# XR and Device Checklist

## Check

- target headset or simulator
- loader and runtime
- controller bindings
- tracking origin
- interaction layers
- locomotion
- tracking loss
- recentering
- performance
- device-specific features
- haptics
- permissions

Strong XR validation requires target hardware when device-specific behavior is
involved.
