# Release Candidate Checklist

## Confirm

- clean source state or documented changes
- intended Unity version
- intended package lock
- release build configuration
- version number
- scenes
- target platforms
- tests
- smoke scenarios
- save compatibility
- multiplayer topology
- performance budget
- crash and error logs
- artifact naming
- checksums when required
- release notes
- rollback or previous build availability

Any skipped release-blocking criterion prevents Ready status.
