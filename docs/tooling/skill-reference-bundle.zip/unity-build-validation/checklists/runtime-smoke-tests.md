# Runtime Smoke Test Checklist

## Define

- scene
- feature
- steps
- expected result
- repetition count
- cleanup behavior

## Check

- startup
- primary feature path
- repeated use
- disable and enable
- scene reload
- object destruction or despawn
- pause or time scale
- Console output
- application exit when relevant

## Reporting

State exactly what was exercised.

Do not report “Play Mode passed” without a scenario.
