# Performance Budget Checklist

Use only when budgets or performance claims are relevant.

## Define

- target hardware
- scene
- build type
- frame rate target
- CPU budget
- GPU budget
- memory budget
- allocation budget
- network budget

## Measure

- equivalent before and after conditions
- stable capture window
- representative workload
- spikes and steady state
- memory growth
- allocations
- draw calls or overdraw
- network send rate

Do not claim compliance without measurement.
