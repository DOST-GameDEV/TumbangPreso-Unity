# Unity Project Context

<!-- unity-onboarding:generated:start -->

## Project Summary

- Project root:
- Last analyzed:
- Last analyzed commit:

## Confirmed Environment

- Unity version:
- Render pipeline:
- Input system:
- Target platforms:

## Important Packages And Frameworks

| Area | Finding | Confidence | Evidence |
| --- | --- | --- | --- |

## Directory Structure

| Path | Purpose | Confidence | Evidence |
| --- | --- | --- | --- |

## Assembly Boundaries

| Assembly | Responsibility | Key references | Notes |
| --- | --- | --- | --- |

## Scenes And Startup Flow

- Build scenes:
- Likely startup scene:
- Scene loading flow:

## Architecture

| Pattern | Finding | Confidence | Evidence |
| --- | --- | --- | --- |

## Coding Conventions

- Namespace style:
- Serialized fields:
- Async:
- Comments/docs:

## Testing And Validation

- EditMode tests:
- PlayMode tests:
- CI/build validation:

## Available Unity Tooling

| Capability | Status | Evidence |
| --- | --- | --- |
| `unity.connection.status` | unverified | |
| `unity.editor.version` | unverified | |
| `unity.console.read` | unverified | |
| `unity.scene.list` | unverified | |
| `unity.scene.inspect` | unverified | |
| `unity.buildsettings.read` | unverified | |
| `unity.gameobject.inspect` | unverified | |
| `unity.asset.search` | unverified | |
| `unity.package.read` | unverified | |
| `unity.tests.list` | unverified | |
| `unity.tests.run` | unverified | |
| `unity.playmode.read` | unverified | |
| `unity.profiler.read` | unverified | |

## Important Constraints

-

## Unknowns And Confidence

-

## Source Files Inspected

-

<!-- unity-onboarding:generated:end -->

