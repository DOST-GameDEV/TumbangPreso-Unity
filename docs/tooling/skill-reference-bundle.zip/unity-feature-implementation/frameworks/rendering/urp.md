# Universal Render Pipeline Guide

Use only when the project actively uses URP.

## Inspect

- URP package version
- pipeline assets
- renderer assets
- renderer features
- camera stacking
- shader graph targets

## Rules

- Match the active URP version.
- Preserve SRP Batcher compatibility.
- Validate renderer feature ordering.
- Consider camera stacking.
- Avoid modifying shared pipeline assets casually.
- Validate target-platform support.
