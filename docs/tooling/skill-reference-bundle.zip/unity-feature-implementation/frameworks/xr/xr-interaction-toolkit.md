# XR Interaction Toolkit Guide

Use only when the project actively uses XR Interaction Toolkit.

## Inspect

- toolkit version
- XR Interaction Manager
- interactors and interactables
- locomotion providers
- interaction layers
- action-based versus device-based input
- grab transformers

## Rules

- Reuse existing interaction managers.
- Preserve interaction-layer conventions.
- Respect select, activate, and hover semantics.
- Avoid duplicate input ownership.
- Handle attach transforms and throw behavior carefully.
- Validate with target controller mappings.
