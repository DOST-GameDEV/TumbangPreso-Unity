# UI Toolkit Framework Guide

Use only when the project actively uses UI Toolkit.

## Inspect

- UXML
- USS
- PanelSettings
- UIDocument ownership
- binding approach
- editor versus runtime usage
- navigation
- localization

## Rules

- Preserve UXML and USS separation.
- Reuse class names and style conventions.
- Avoid querying the visual tree repeatedly.
- Register and unregister callbacks.
- Keep view-model or presenter boundaries clear.
- Validate runtime panel configuration.
