# uGUI Framework Guide

Use only when the project actively uses Canvas-based uGUI.

## Inspect

- Canvas hierarchy
- EventSystem
- navigation
- prefab ownership
- presenter or controller pattern
- localization
- layout groups

## Rules

- Avoid repeated listener registration.
- Preserve navigation.
- Avoid unnecessary layout rebuilds.
- Reuse prefabs and presenters.
- Keep gameplay state outside views.
- Validate anchors, scaling, and resolution behavior.
