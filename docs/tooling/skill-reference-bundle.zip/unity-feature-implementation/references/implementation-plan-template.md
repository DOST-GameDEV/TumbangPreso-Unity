# Unity Feature Implementation Plan

## Feature contract

**Requested behavior:**

{{REQUESTED_BEHAVIOR}}

**Acceptance criteria:**

- {{CRITERION_1}}
- {{CRITERION_2}}
- {{CRITERION_3}}

## Routed guidance

### Foundations

- {{FOUNDATION}}

### Specializations

- {{SPECIALIZATION}}

### Frameworks

- {{FRAMEWORK}}

## Existing system

**Current owner:**

{{CURRENT_OWNER}}

**Relevant architecture:**

{{ARCHITECTURE}}

**Existing extension points:**

{{EXTENSION_POINTS}}

## Scope

### Files to create

- `{{PATH}}` — {{PURPOSE}}

### Files to modify

- `{{PATH}}` — {{CHANGE}}

### Serialized assets

- `{{PATH}}` — {{CHANGE_OR_INSPECTION}}

## Implementation sequence

1. {{STEP_1}}
2. {{STEP_2}}
3. {{STEP_3}}
4. {{STEP_4}}

## Validation

- Compilation: {{METHOD}}
- Tests: {{TESTS}}
- Runtime: {{RUNTIME_CHECK}}
- Serialized setup: {{ASSET_CHECK}}
- Multiplayer or platform: {{SPECIAL_CHECK}}

## Risks

| Risk | Impact | Mitigation |
|---|---|---|
| {{RISK}} | {{IMPACT}} | {{MITIGATION}} |

## Assumptions

- {{ASSUMPTION}}

## Out of scope

- {{OUT_OF_SCOPE_ITEM}}
