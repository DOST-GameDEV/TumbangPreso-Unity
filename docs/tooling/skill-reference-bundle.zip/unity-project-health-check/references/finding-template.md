# Health Finding

**ID:** {{ID}}

**Title:** {{TITLE}}

**Domain:** {{DOMAIN}}

**Severity:** Critical / High / Medium / Low / Informational

**Confidence:** Confirmed / Likely / Possible

## Observation

{{OBSERVATION}}

## Evidence

- `{{PATH}}`
- {{OTHER_EVIDENCE}}

## Impact

{{IMPACT}}

## Recommendation

{{RECOMMENDATION}}

## Remediation size

Small / Medium / Large / Unknown

## Validation needed

{{VALIDATION}}

## Related findings

{{RELATED}}
