# Unity Health Check Plan

## Audit mode

Focused / Standard / Release readiness / Deep

## Target

- Unity:
- Platform:
- Commit:
- Project stage:

## Domains

- [ ] Architecture
- [ ] Code quality
- [ ] Lifecycle
- [ ] Assemblies
- [ ] Packages
- [ ] Scenes and serialization
- [ ] Performance
- [ ] Memory and assets
- [ ] Rendering
- [ ] Multiplayer
- [ ] Persistence
- [ ] UI and localization
- [ ] Input
- [ ] Tests
- [ ] Builds and CI
- [ ] Security
- [ ] Editor tooling
- [ ] Project hygiene

## Tooling

- Unity Editor:
- Console:
- Tests:
- Profiler:
- Build:
- Device:
- Multiplayer peers:

## Limitations

-
