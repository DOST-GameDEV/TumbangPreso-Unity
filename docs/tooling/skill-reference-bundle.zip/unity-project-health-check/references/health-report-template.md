# Unity Project Health Report

> Last analyzed: {{DATE}}
> Commit: `{{COMMIT}}`
> Scope: {{SCOPE}}
> Project root: `{{PROJECT_ROOT}}`

## Overall assessment

{{OVERALL}}

## Coverage

### Checked

{{CHECKED}}

### Not checked

{{NOT_CHECKED}}

## Priority findings

| ID | Severity | Confidence | Domain | Finding |
|---|---|---|---|---|
{{PRIORITY_ROWS}}

## Detailed findings

{{FINDINGS}}

## Healthy areas

{{HEALTHY_AREAS}}

## Recommended remediation order

1. {{ACTION_1}}
2. {{ACTION_2}}
3. {{ACTION_3}}

## Validation baseline

{{BASELINE}}

## Limitations

{{LIMITATIONS}}

## Team notes

Manual notes may be added here.
