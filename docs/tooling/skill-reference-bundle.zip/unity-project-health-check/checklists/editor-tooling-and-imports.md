# Editor Tooling and Imports Checklist

Inspect:

- UnityEditor references in runtime assemblies
- custom inspectors
- Undo support
- asset import loops
- AssetDatabase use
- generated assets
- domain reload state
- menu collisions
- long blocking editor operations
- import dependencies
- dirty-state handling
- sample or development tools in builds

Editor issues can affect team productivity even when runtime is healthy.
