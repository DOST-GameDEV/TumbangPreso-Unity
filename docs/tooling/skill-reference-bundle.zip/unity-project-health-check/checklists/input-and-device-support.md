# Input and Device Support Checklist

Inspect:

- active input system
- action-map lifecycle
- duplicate callbacks
- generated wrappers
- control schemes
- rebinding
- local multiplayer
- UI and gameplay transitions
- focus loss
- touch or gamepad support
- device-specific assumptions
- update mode
- input buffering

Treat input action assets as serialized high-impact configuration.
