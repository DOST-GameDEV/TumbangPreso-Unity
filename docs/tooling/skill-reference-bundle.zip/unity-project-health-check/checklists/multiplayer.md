# Multiplayer Checklist

Inspect:

- active networking framework
- authority and ownership
- replicated state
- RPC direction
- late join
- spawn registration
- disconnect cleanup
- host-only assumptions
- per-frame traffic
- prediction and reconciliation
- duplicated local and network simulation
- trust boundaries
- network object lifetime
- reconnect behavior
- multi-peer tests

Do not claim networking health from a single instance.
