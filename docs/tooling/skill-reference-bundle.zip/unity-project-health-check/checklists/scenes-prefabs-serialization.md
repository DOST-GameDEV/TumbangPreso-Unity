# Scenes, Prefabs, and Serialization Checklist

Inspect:

- Build Settings scenes
- likely startup scene
- missing references
- prefab variants
- scene overrides
- duplicate GUID risk
- serialized field renames
- type changes
- large shared prefabs
- reusable prefabs with scene references
- ScriptableObject defaults
- custom inspectors
- asset ownership
- accidental scene serialization changes

Use Editor or MCP inspection when available.
