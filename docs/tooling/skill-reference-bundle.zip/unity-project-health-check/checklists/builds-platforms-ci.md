# Builds, Platforms, and CI Checklist

Inspect:

- build scenes
- build profiles
- target platforms
- scripting backend
- API compatibility
- graphics APIs
- stripping
- platform defines
- native plugins
- case-sensitive paths
- CI workflows
- reproducible build commands
- secrets handling
- artifact output
- development versus release configuration
- known build warnings

Release readiness requires actual build evidence when possible.
