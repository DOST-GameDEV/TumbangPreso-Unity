# Packages and Compatibility Checklist

Inspect:

- manifest and lock file
- Git and local packages
- scoped registries
- package pinning
- Unity-version compatibility
- deprecated packages
- overlapping frameworks
- embedded package ownership
- unresolved or floating Git references
- package samples in production folders
- transitive package churn
- platform support

Do not recommend package updates solely because a newer version exists.
