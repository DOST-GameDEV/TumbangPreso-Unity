# Testing and Validation Checklist

Inspect:

- Unity Test Framework
- EditMode tests
- PlayMode tests
- flaky or disabled tests
- CI test execution
- coverage of critical rules
- regression tests
- target-platform validation
- multiplayer tests
- save migration fixtures
- test assembly structure
- test data ownership
- baseline failures

Do not use test count alone as a quality measure.
