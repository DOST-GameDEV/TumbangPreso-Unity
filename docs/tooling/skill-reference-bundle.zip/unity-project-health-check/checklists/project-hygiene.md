# Project Hygiene Checklist

Inspect:

- `.gitignore`
- generated folders
- IDE artifacts
- large binary files
- duplicate assets
- abandoned experiments
- sample content
- backup files
- naming consistency
- folder ownership
- documentation freshness
- stale context files
- merge-sensitive assets
- package lock consistency
- license files for third-party content

Do not recommend reorganization without a clear maintenance benefit.
