# Rendering and VFX Checklist

Inspect:

- active render pipeline
- shader compatibility
- shader warnings
- material instances
- renderer features
- camera stacking
- transparent overdraw
- VFX particle limits
- effect pooling
- shadow configuration
- render texture resolution
- post-processing
- shader variants
- platform graphics support
- visual-only network synchronization

Use framework-specific rendering guidance when applicable.
