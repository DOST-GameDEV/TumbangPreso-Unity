# Security and Secrets Checklist

Inspect for:

- committed API keys
- tokens
- passwords
- private certificates
- insecure local storage
- client-trusted gameplay outcomes
- unsafe remote commands
- unvalidated network messages
- sensitive logs
- debug endpoints
- platform credential files
- exposed cloud configuration

Do not reproduce secret values in reports.
