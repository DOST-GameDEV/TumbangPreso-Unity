# Save and Persistence Checklist

Inspect:

- save format
- versioning
- migration
- defaults
- atomic writes
- corruption recovery
- cloud synchronization
- platform paths
- culture-dependent serialization
- encryption or secrets
- duplicate state
- old save compatibility
- save frequency
- blocking IO
- multiplayer ownership

Data-loss risk receives high priority.
