# HDRP Health Review

Inspect:

- HDRP version
- pipeline assets
- volume profiles
- custom passes
- frame settings
- graphics APIs
- target hardware
- shader targets
- ray tracing settings
- shared profile ownership

Common risks:

- unsupported hardware assumptions
- custom-pass ordering
- shared profile mutation
- expensive default settings
