# URP Health Review

Inspect:

- URP version
- pipeline assets
- renderer assets
- renderer features
- feature ordering
- camera stacking
- shader graph targets
- SRP Batcher compatibility
- platform support
- shared asset ownership

Common risks:

- wrong renderer assigned
- shared pipeline asset changes
- incompatible shader targets
- excessive renderer features
