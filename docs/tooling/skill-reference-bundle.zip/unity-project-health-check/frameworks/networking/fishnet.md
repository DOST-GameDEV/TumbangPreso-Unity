# FishNet Health Review

Inspect:

- NetworkManager
- ownership
- SyncTypes
- RPC usage
- prediction and reconcile
- observer behavior
- spawn and despawn
- scene management
- multi-peer tests

Common risks:

- duplicated observer effects
- incomplete reconcile state
- stale ownership
- persistent state represented only by RPCs
