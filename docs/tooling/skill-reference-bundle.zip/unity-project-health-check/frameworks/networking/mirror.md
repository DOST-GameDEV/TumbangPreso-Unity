# Mirror Health Review

Inspect:

- NetworkManager
- Commands
- ClientRpc and TargetRpc
- SyncVars
- authority
- spawn registration
- scene flow
- host versus remote-client paths
- transport configuration

Common risks:

- duplicate host execution
- Commands without authority
- local mutation of server state
- missing spawn registration
