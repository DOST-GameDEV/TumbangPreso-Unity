# Unity Project Health Check Skill

A read-only-by-default Codex skill for auditing Unity project quality, risk,
maintainability, performance, compatibility, and release readiness.

## Structure

- `SKILL.md`: audit workflow and router
- `foundations/`: evidence, severity, safety, reporting
- `checklists/`: health domains
- `frameworks/`: networking and rendering criteria
- `references/`: finding, scoring, planning, and report templates

## Recommended pairing

- `unity-project-onboarding`
- `unity-bug-investigation`
- `unity-feature-implementation`
- `unity-build-validation`

## Design philosophy

- evidence-based findings
- read-only by default
- severity plus confidence
- prioritize impact over style
- respect existing architecture
- actionable remediation
- explicit audit limitations
